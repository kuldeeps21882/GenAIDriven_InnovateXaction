# Welcome Phase

1. **Explain AI-DLC Process to User**: Load and present complete process overview from `introduction/process-overview.md`